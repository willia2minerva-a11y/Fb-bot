export const skills = [
  { id: 'power_strike', name: 'ضربة قوية', type: 'offensive', power: 8, manaCost: 5 },
  { id: 'magic_blast', name: 'انفجار سحري', type: 'offensive', power: 12, manaCost: 10 },
  { id: 'shield_wall', name: 'جدار الحماية', type: 'defensive', defense: 10, manaCost: 7 },
  { id: 'heal', name: 'تعويذة علاجية', type: 'healing', heal: 20, manaCost: 6 },
];