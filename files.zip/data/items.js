export const weapons = [
  // --- الأسلحة الضعيفة إلى المتوسطة ---
  {
    id: "bronze_dagger",
    name: "خنجر البرونز",
    type: "weapon",
    damage: 15,
    obtain: "صناعي",
    craft: { materials: [{ item: "Bronze Bar", quantity: 5 }] },
    tier: "weak"
  },
  {
    id: "iron_sword",
    name: "سيف الحديد",
    type: "weapon",
    damage: 25,
    obtain: "صناعي",
    craft: { materials: [{ item: "Iron Bar", quantity: 8 }] },
    tier: "weak"
  },
  {
    id: "steel_mace",
    name: "مطرقة الصلب",
    type: "weapon",
    damage: 35,
    obtain: "صناعي",
    craft: { materials: [{ item: "Steel Bar", quantity: 10 }] },
    tier: "weak"
  },
  {
    id: "wooden_bow",
    name: "قوس خشبي",
    type: "weapon",
    damage: 20,
    obtain: "صناعي",
    craft: { materials: [{ item: "Wood", quantity: 5 }, { item: "Iron Bar", quantity: 3 }] },
    tier: "weak"
  },
  {
    id: "silver_sword",
    name: "سيف الفضة",
    type: "weapon",
    damage: 40,
    obtain: "صناعي",
    craft: { materials: [{ item: "Silver Bar", quantity: 7 }] },
    tier: "weak"
  },

  // --- الأسلحة المتوسطة ---
  {
    id: "flame_staff",
    name: "عصا اللهب",
    type: "weapon",
    damage: 60,
    obtain: "يسقطها Fire Wyrm",
    drop: { from: "Fire Wyrm", chance: 20 },
    tier: "mid"
  },
  {
    id: "ice_blade",
    name: "سيف الجليد",
    type: "weapon",
    damage: 55,
    obtain: "يسقطها Ice Demon",
    drop: { from: "Ice Demon", chance: 25 },
    tier: "mid"
  },
  {
    id: "dark_spear",
    name: "رمح الظلام",
    type: "weapon",
    damage: 70,
    obtain: "يسقطها Dark Soldier",
    drop: { from: "Dark Soldier", chance: 15 },
    tier: "mid"
  },
  {
    id: "silver_bow",
    name: "قوس الفضة",
    type: "weapon",
    damage: 45,
    obtain: "صناعي",
    craft: { materials: [{ item: "Silver Bar", quantity: 8 }, { item: "Wood", quantity: 5 }] },
    tier: "mid"
  },
  {
    id: "poisonous_dagger",
    name: "خنجر السم",
    type: "weapon",
    damage: 50,
    obtain: "يسقطه Ghoul",
    drop: { from: "Ghoul", chance: 10 },
    tier: "mid"
  },

  // --- الأسلحة القوية ---
  {
    id: "dragon_slayer",
    name: "قاتل التنين",
    type: "weapon",
    damage: 120,
    obtain: "يسقطه Dragon King",
    drop: { from: "Dragon King", chance: 5 },
    tier: "high"
  },
  {
    id: "death_scythe",
    name: "منجل الموت",
    type: "weapon",
    damage: 130,
    obtain: "يسقطه Death Knight",
    drop: { from: "Death Knight", chance: 10 },
    tier: "high"
  },
  {
    id: "flame_dragon_blade",
    name: "سيف تنين اللهب",
    type: "weapon",
    damage: 150,
    obtain: "يسقطه Fire Wyrm",
    drop: { from: "Fire Wyrm", chance: 15 },
    tier: "high"
  },
  {
    id: "abyssal_edge",
    name: "حدود الهاوية",
    type: "weapon",
    damage: 160,
    obtain: "يسقطه Abyssal Lord",
    drop: { from: "Abyssal Lord", chance: 10 },
    tier: "high"
  },
  {
    id: "phoenix_bow",
    name: "قوس الفينيق",
    type: "weapon",
    damage: 170,
    obtain: "يسقطه Infernal Beast",
    drop: { from: "Infernal Beast", chance: 10 },
    tier: "high"
  },

  // --- الأسلحة الأسطورية ---
  {
    id: "excalibur_legendary",
    name: "إكسكالابور",
    type: "weapon",
    damage: 200,
    obtain: "يصنع باستخدام Soul of Light و Soul of Might",
    craft: { materials: [{ item: "Soul of Light", quantity: 10 }, { item: "Soul of Might", quantity: 10 }] },
    tier: "legendary"
  },
  {
    id: "deathbringer",
    name: "المؤتي بالموت",
    type: "weapon",
    damage: 250,
    obtain: "يسقطه Dark Lord",
    drop: { from: "Dark Lord", chance: 5 },
    tier: "legendary"
  },
  {
    id: "gods_wrath",
    name: "غضب الإله",
    type: "weapon",
    damage: 300,
    obtain: "يسقطه Shadow Monarch",
    drop: { from: "Shadow Monarch", chance: 2 },
    tier: "legendary"
  },
  {
    id: "doomhammer",
    name: "مطرقة الهلاك",
    type: "weapon",
    damage: 350,
    obtain: "يسقطها Monarch of Destruction",
    drop: { from: "Monarch of Destruction", chance: 1 },
    tier: "legendary"
  },
  {
    id: "divine_sword",
    name: "سيف الإله",
    type: "weapon",
    damage: 400,
    obtain: "يصنع باستخدام Divine Fragments و Sacred Steel",
    craft: { materials: [{ item: "Divine Fragments", quantity: 5 }, { item: "Sacred Steel", quantity: 10 }] },
    tier: "legendary"
  },

  // --- الأسلحة الأسطورية المتقدمة ---
  {
    id: "soulfire_blade",
    name: "سيف نار الروح",
    type: "weapon",
    damage: 500,
    obtain: "يصنع من Soul Shards و Dark Iron",
    craft: { materials: [{ item: "Soul Shards", quantity: 10 }, { item: "Dark Iron", quantity: 15 }] },
    tier: "mythic"
  },
  {
    id: "oblivions_end",
    name: "نهاية العدم",
    type: "weapon",
    damage: 600,
    obtain: "يسقطها Abyssal Overlord",
    drop: { from: "Abyssal Overlord", chance: 1 },
    tier: "mythic"
  },
  {
    id: "divinitys_edge",
    name: "حدود الإلوهية",
    type: "weapon",
    damage: 700,
    obtain: "يسقطها Celestial God",
    drop: { from: "Celestial God", chance: 1 },
    tier: "mythic"
  }
];