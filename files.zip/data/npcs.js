export const npcs = [
  { id: 'vendor', name: 'البائع', role: 'merchant', description: 'يبيع الأدوات والأسلحة.' },
  { id: 'trainer', name: 'المدرب', role: 'trainer', description: 'يعلمك المهارات الجديدة.' },
  { id: 'developer', name: 'المطور', role: 'upgrader', description: 'يطور أسلحتك ودروعك مقابل ذهب.' },
  { id: 'sage', name: 'المعلم', role: 'mentor', description: 'يعلمك الأسرار بعد إتمام المهام.' },
];