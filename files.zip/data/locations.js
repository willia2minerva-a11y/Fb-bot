export const locations = [
  {
    id: "forest",
    name: "الغابات",
    monsters: [
      "slime",
      "demon_eye",
      "wild_boar",
      "queen_bee",
      "king_slime",
      "eye_of_cthulhu"
    ]
  },
  {
    id: "underground_jungle",
    name: "الغابة الجوفية",
    monsters: [
      "queen_bee",
      "plantera",
      "golem",
      "ice_queen"
    ]
  },
  // ... (بقية المناطق)
];